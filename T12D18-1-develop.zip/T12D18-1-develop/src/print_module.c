#include <stdio.h>

#include "print_module.h"

int print_char(char ch) 
{
    return putchar(ch);
}
